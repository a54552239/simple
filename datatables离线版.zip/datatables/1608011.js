var cx=parseInt(Math.random()*2+1,10);
console.log('V60907ADC');
document.writeln("<style>#myg {width:100%; height:128px; margin-left:6px;}</style>");
document.writeln("<style>#myg:hover{border:1px solid #000;} .mygp{font-family:微软雅黑;color:#FF2E31;margin:0px;}</style>");
document.writeln("<style>#myg a{text-decoration:none;}</style>");

document.writeln('<div id="myg" align="center">');
switch(cx)
{
case 1:
  document.writeln('<a href="http://320023.com/ttb536804390116" target="_blank"><img src="img02.png"/*tpa=http://cdn63.320023.com/320023_/myg/g160801/img02.png*/ width="100%" /><p class="mygp">高清手机钢化膜活动仅需8元（包邮）</p></a>');
  break;
case 2:
  document.writeln('<a href="http://320023.com/ttb536852445392" target="_blank"><img src="img01.jpg"/*tpa=http://cdn63.320023.com/320023_/myg/g160801/img01.jpg*/ width="100%" /><p class="mygp">乐心手环心率版168元（包邮）</p></a>');
  break;
case 6:
  x="Today it's Saturday";
  break;
}
document.writeln('</div>');